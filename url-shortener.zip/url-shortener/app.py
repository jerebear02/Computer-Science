import os
import random
import string
import sqlite3

from flask import Flask, redirect, render_template, request, jsonify

app = Flask(__name__)
DB_PATH = "urls.db"


# ── DB helpers ────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    with open("schema.sql") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def generate_code(length=6):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=length))


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    conn = get_db()
    recent = conn.execute(
        "SELECT short, original, clicks FROM urls ORDER BY created DESC LIMIT 8"
    ).fetchall()
    total = conn.execute("SELECT COUNT(*) as c FROM urls").fetchone()["c"]
    total_clicks = conn.execute("SELECT SUM(clicks) as c FROM urls").fetchone()["c"] or 0
    conn.close()
    return render_template("index.html", recent=recent, total=total, total_clicks=total_clicks)


@app.route("/shorten", methods=["POST"])
def shorten():
    data     = request.get_json()
    original = data.get("url", "").strip()

    if not original:
        return jsonify({"error": "No URL provided"}), 400

    if not original.startswith(("http://", "https://")):
        original = "https://" + original

    conn = get_db()

    # Check if already shortened
    existing = conn.execute(
        "SELECT short FROM urls WHERE original = ?", (original,)
    ).fetchone()

    if existing:
        conn.close()
        return jsonify({"short": existing["short"], "original": original})

    # Generate unique code
    code = generate_code()
    while conn.execute("SELECT id FROM urls WHERE short = ?", (code,)).fetchone():
        code = generate_code()

    conn.execute(
        "INSERT INTO urls (original, short) VALUES (?, ?)", (original, code)
    )
    conn.commit()
    conn.close()

    return jsonify({"short": code, "original": original})


@app.route("/<code>")
def redirect_url(code):
    conn = get_db()
    row = conn.execute(
        "SELECT original FROM urls WHERE short = ?", (code,)
    ).fetchone()

    if not row:
        conn.close()
        return render_template("index.html", error=f"/{code} not found"), 404

    conn.execute(
        "UPDATE urls SET clicks = clicks + 1 WHERE short = ?", (code,)
    )
    conn.commit()
    conn.close()

    return redirect(row["original"])


@app.route("/api/stats/<code>")
def stats(code):
    conn = get_db()
    row = conn.execute(
        "SELECT original, short, clicks, created FROM urls WHERE short = ?", (code,)
    ).fetchone()
    conn.close()

    if not row:
        return jsonify({"error": "Not found"}), 404

    return jsonify(dict(row))


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        init_db()
    app.run(debug=True)
