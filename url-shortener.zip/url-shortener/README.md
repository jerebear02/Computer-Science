# SNIP — URL Shortener

A Flask + SQLite URL shortener. Paste a long URL, get a short one. Click tracking included.

## Features

- Shortens any URL to a 6-character alphanumeric code
- Redirects short URLs to the original
- Tracks click count per link
- Prevents duplicate entries for the same URL
- Displays recent links on the homepage

## Setup

```bash
git clone <your-repo-url>
cd url-shortener
pip install -r requirements.txt
python app.py
```

Open `http://localhost:5000`

## Project Structure

```
url-shortener/
├── app.py              # Flask routes + SQLite logic
├── schema.sql          # Database schema + index
├── requirements.txt
├── README.md
└── templates/
    └── index.html      # Frontend
```

## API

| Route | Method | Description |
|---|---|---|
| `/` | GET | Homepage with recent links |
| `/shorten` | POST | Shorten a URL, returns `{ short, original }` |
| `/<code>` | GET | Redirect to original URL |
| `/api/stats/<code>` | GET | JSON stats for a short link |

## Tech Stack

Python, Flask, SQLite (`sqlite3` stdlib), Vanilla HTML/CSS/JS
